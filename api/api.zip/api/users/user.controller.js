const { create, getUserByPhone } = require("./user.service");
const { genSaltSync, hashSync, compareSync } = require("bcrypt");
const jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");

module.exports = {
  createUser: (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res
        .status(400)
        .json({ status: "error", message: errors.array() });
    }

    const body = req.body;
    console.log("Incoming request body:", body);

    getUserByPhone(body.email, (err, user) => {
      if (err) {
        console.log(err);
        return res
          .status(500)
          .json({ status: "error", message: err });
      }

      if (user) {
        return res
          .status(409)
          .json({ status: "error", message: "User already exists" });
      }

      const salt = genSaltSync(10);
      body.password = hashSync(body.password, salt);

      create(body, (err, results) => {
        if (err) {
          console.log(err);
          return res.status(500).json({
            status: "error",
            message: err.message || "Database connection error",
          });
        }

        return res.status(200).json({
          status: "success",
          message: "User created successfully",
          data: results,
        });
      });
    });
  },

  loginUser: (req, res) => {
    const body = req.body;
    if (!body.email || !body.password) {
      return res.status(400).json({
        status: "error",
        message: "Email and password required"
      });
    }

    getUserByPhone(body.email, (err, user) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ status: "error", message: "Database error" });
      }

      if (!user) {
        return res.status(404).json({ status: "error", message: "User not found" });
      }

      const isPasswordCorrect = compareSync(body.password, user.password);
      if (!isPasswordCorrect) {
        return res.status(401).json({ status: "error", message: "Invalid password" });
      }

      user.password = undefined; // remove hashed password from response
      const token = jwt.sign({ user }, process.env.JWT_USER, {
        expiresIn: "30d"
      });

      return res.json({
        status: "success",
        message: "Login successful",
        token: token,
        user: user
      });
    });
  },

  getUserProfile: (req, res) => {
    const userData = req.user.user;

    getUserByPhone(userData.email, (err, user) => {
      if (err) {
        console.log(err);
        return res.status(500).json({
          success: 0,
          message: "Database error"
        });
      }

      if (!user) {
        return res.status(404).json({
          success: 0,
          message: "User not found"
        });
      }

      user.password = undefined; // hide password
      return res.status(200).json({
        success: 1,
        data: user
      });
    });
  },
  


};