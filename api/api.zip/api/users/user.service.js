const pool = require("../../config/database");
const transporter = require("../../utils/mailer"); // <-- your Nodemailer setup

module.exports = {
  create: (data, callBack) => {
    pool.query(
      "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
      [data.name, data.email, data.password, "user"],
      (error, results) => {
        if (error) {
          return callBack(error);
        }

        const insertedId = results.insertId;

        // --- Insert permissions ---
        const permValues = [
          [insertedId, "front_office", ...data.front_office],
          [insertedId, "accounts", ...data.accounts],
          [insertedId, "asset_management", ...data.asset_management],
          [insertedId, "inventory", ...data.inventory],
        ];

        const permPlaceholders = permValues
          .map(() => "(?, ?, ?, ?, ?, ?)")
          .join(",");

        pool.query(
          `INSERT INTO user_permissions (user_id, module, create_permission, view_permission, edit_permission, del_permission) 
           VALUES ${permPlaceholders}`,
          permValues.flat(),
          (permError, permResults) => {
            if (permError) {
              return callBack(permError);
            }

            // --- Branches (must be at least 1, validated in controller) ---
            const branches = Array.isArray(data.branches) ? data.branches : [];
            if (branches.length === 0) {
              return callBack(
                new Error("At least one branch must be assigned")
              );
            }

            const branchValues = branches.map((branchId) => [
              insertedId,
              branchId,
            ]);
            const branchPlaceholders = branchValues
              .map(() => "(?, ?)")
              .join(",");

            pool.query(
              `INSERT INTO assigned_branches (user_id, branch_id) VALUES ${branchPlaceholders}`,
              branchValues.flat(),
              (branchError, branchResults) => {
                if (branchError) {
                  return callBack(branchError);
                }
                return callBack(null, {
                  userId: insertedId,
                  permissionsInserted: permResults.affectedRows,
                  branchesInserted: branchResults.affectedRows,
                });
              }
            );
          }
        );
      }
    );
  },

  getUserByPhone: (email, callBack) => {
    pool.query(
      `SELECT 
          u.id, u.name, u.email, u.password, u.role, u.created_at,
          (SELECT JSON_ARRAYAGG(JSON_OBJECT('branch_id',b.id,'branch_name',b.branch_name,'address',b.address, 'phone_one', b.phone_one, 'phone_two', b.phone_two, 'email', b.email, 'logo_path', b.logo_path))
           FROM assigned_branches ab 
           JOIN branches b ON ab.branch_id=b.id 
           WHERE ab.user_id=u.id) AS branches,
          (SELECT JSON_ARRAYAGG(JSON_OBJECT('module',up.module,'create_permission',up.create_permission,'view_permission',up.view_permission,'edit_permission',up.edit_permission,'del_permission',up.del_permission))
           FROM user_permissions up 
           WHERE up.user_id=u.id) AS permissions
       FROM users u 
       WHERE u.email=?`,
      [email],
      (error, results) => {
        if (error) {
          return callBack(error);
        }

        if (results.length === 0) {
          return callBack(null, null);
        }

        let user = results[0];
        user.branches = JSON.parse(user.branches || '[]');
        user.permissions = JSON.parse(user.permissions || '[]');

        return callBack(null, user);
      }
    );
  },

  getUsers: (callBack) => {
    pool.query(
      `SELECT 
          u.id, u.name, u.email, 
          up.module, up.create_permission, up.view_permission, up.edit_permission, up.del_permission, 
          b.id AS branch_id, b.branch_name 
       FROM users u 
       LEFT JOIN user_permissions up ON up.user_id = u.id
       LEFT JOIN assigned_branches ab ON ab.user_id = u.id
       LEFT JOIN branches b ON b.id = ab.branch_id
       WHERE u.role = "user"`,
      [],
      (error, results) => {
        if (error) return callBack(error);

        const userMap = new Map();

        results.forEach(row => {
          if (!userMap.has(row.id)) {
            userMap.set(row.id, {
              id: row.id,
              name: row.name,
              email: row.email,
              permissions: [],
              branches: [],
              __permissionsSet: new Set(), 
              __branchesSet: new Set()
            });
          }

          const user = userMap.get(row.id);

          if (row.module) {
            const permKey = `${row.module}-${row.create_permission}-${row.view_permission}-${row.edit_permission}-${row.del_permission}`;
            if (!user.__permissionsSet.has(permKey)) {
              user.__permissionsSet.add(permKey);
              user.permissions.push({
                module: row.module,
                create: row.create_permission,
                view: row.view_permission,
                edit: row.edit_permission,
                del: row.del_permission
              });
            }
          }

          if (row.branch_id && !user.__branchesSet.has(row.branch_id)) {
            user.__branchesSet.add(row.branch_id);
            user.branches.push({
              id: row.branch_id,
              name: row.branch_name
            });
          }
        });

        const formatted = Array.from(userMap.values()).map(user => {
          delete user.__permissionsSet;
          delete user.__branchesSet;
          return user;
        });

        return callBack(null, formatted);
      }
    );
  },

  getBranchPermissions: (id, callBack) => {
    pool.query(
      `SELECT b.id as branch_id, b.branch_name, b.address, b.phone_one, b.phone_two, b.email, b.bin, b.trade_lin, b.logo_path FROM assigned_branches ab
      INNER JOIN branches b ON b.id = ab.branch_id
      WHERE ab.user_id = ?`,
      [id],
      (error, results) => {
        if (error) {
          return callBack(error);
        }

        return callBack(null, results);
      }
    );
  },

  getModulePermissions: (data, callBack) => {
    pool.query(
      `SELECT create_permission, view_permission, edit_permission, del_permission FROM user_permissions WHERE user_id = ? AND module = ?`,
      [data.user_id, data.module],
      (error, results) => {
        if (error) {
          return callBack(error);
        }

        return callBack(null, results);
      }
    );
  },

  getModules: (id, callBack) => {
    pool.query(
      `SELECT module FROM user_permissions WHERE view_permission = ? AND user_id = ?`,
      [1, id],
      (error, results) => {
        if (error) {
          return callBack(error);
        }

        return callBack(null, results);
      }
    );
  },

  changePassword: (data, callBack) => {
    pool.query(
      `UPDATE users SET password = ? WHERE email = ?`,
      [data.password, data.email],
      (error, results) => {
        if (error) {
          return callBack(error);
        }

        return callBack(null, results);
      }
    );
  },

  // -------------------
  // 📌 NEW FUNCTION
  // -------------------
  sendOtp: (data, callBack) => {
    const email = data.email;
    const otpMethod = data.otp_method || "reset";

    if (!email) {
      return callBack(new Error("Email is required"));
    }

    // Check if user exists
    pool.query("SELECT id FROM users WHERE email = ?", [email], (err, rows) => {
      if (err) return callBack(err);

      const existingUser = rows.length > 0;

      if (otpMethod === "signup" && existingUser) {
        return callBack(new Error("User already exists! Please login."));
      } else if (otpMethod === "reset" && !existingUser) {
        return callBack(new Error("User not found."));
      }

      // Generate OTP
      const otp = Math.floor(100000 + Math.random() * 900000);
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

      // Check if verification record exists
      pool.query("SELECT id FROM verification WHERE email = ?", [email], (err, verRows) => {
        if (err) return callBack(err);

        if (verRows.length > 0) {
          pool.query(
            "UPDATE verification SET otp=?, expired_at=?, is_verified=0 WHERE email=?",
            [otp, expiresAt, email],
            (err) => {
              if (err) return callBack(err);
              sendMail();
            }
          );
        } else {
          pool.query(
            "INSERT INTO verification (email, otp, is_verified, expired_at) VALUES (?, ?, 0, ?)",
            [email, otp, expiresAt],
            (err) => {
              if (err) return callBack(err);
              sendMail();
            }
          );
        }
      });

      function sendMail() {
        transporter.sendMail(
          {
            from: '"DealzyLoop" <no-reply@dealzyloop.com>',
            to: email,
            subject: "Verify Your Email Address",
            html: `Hello,<br><br>Your verification code is: <strong>${otp}</strong><br><br>This code will expire in 24 hours.`,
            text: `Hello,\n\nYour verification code is: ${otp}\n\nThis code will expire in 24 hours.`,
          },
          (err) => {
            if (err) return callBack(err);
            return callBack(null, { message: "Otp sent successfully in your email." });
          }
        );
      }
    });
  }
};
