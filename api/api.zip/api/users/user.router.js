const { createUser, loginUser, getUserProfile, showUser, showAssignedBranches, showModulePermissions, showModules, updatePass } = require("./user.controller");
const { checkUser, checkToken } = require("../../middleware/auth");
const router = require("express").Router();
const { body, param } = require("express-validator");

router.post(
  "/create",
  [
    body("email").notEmpty().withMessage("email is required"),
    body("name").notEmpty().withMessage("name is required"),
    body("password").notEmpty().withMessage("Password is required"),

    body("front_office")
      .isArray({ min: 4, max: 4 })
      .withMessage("front_office must be an array of exactly 4 values")
      .custom((arr) => arr.every((v) => Number.isInteger(v) && v >= 0 && v <= 1))
      .withMessage("Each item in front_office must be 0 or 1"),

    body("accounts")
      .isArray({ min: 4, max: 4 })
      .withMessage("accounts must be an array of exactly 4 values")
      .custom((arr) => arr.every((v) => Number.isInteger(v) && v >= 0 && v <= 1))
      .withMessage("Each item in accounts must be 0 or 1"),

    body("inventory")
      .isArray({ min: 4, max: 4 })
      .withMessage("inventory must be an array of exactly 4 values")
      .custom((arr) => arr.every((v) => Number.isInteger(v) && v >= 0 && v <= 1))
      .withMessage("Each item in inventory must be 0 or 1"),

    body("asset_management")
      .isArray({ min: 4, max: 4 })
      .withMessage("asset_management must be an array of exactly 4 values")
      .custom((arr) => arr.every((v) => Number.isInteger(v) && v >= 0 && v <= 1))
      .withMessage("Each item in asset_management must be 0 or 1"),

    body("branches")
      .exists({ checkFalsy: true })
      .withMessage("branches is required")
      .isArray({ min: 1 })
      .withMessage("branches must be an array with at least 1 element")
      .custom((arr) => arr.every((v) => Number.isInteger(v) && v >= 1))
      .withMessage("Each branch id must be a positive integer"),
  ],
  checkToken,
  createUser
);

router.post("/login", loginUser);

// Protected routes
router.get("/profile", checkUser, getUserProfile);
router.get("/permissions/branches", checkUser, showAssignedBranches);
router.get("/modules", checkUser, showModules);

router.get("/permissions/modules/:module", 
  [
    param('module')
      .notEmpty().withMessage("Module is required")
  ],
  checkUser, 
  showModulePermissions
);





router.get("/", checkToken, showUser);

module.exports = router;