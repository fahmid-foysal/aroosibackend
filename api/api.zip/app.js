require("dotenv").config(); // ✅ Load environment variables first
const express = require("express");
const cors = require("cors");
const path = require("path");


const app = express();

// ✅ Allow all origins (CORS)
app.use(cors());

// ✅ Parse incoming JSON requests
app.use(express.json());

// Import Routers
const adminRouter = require("./api/admin/admin.router");
const userRouter = require("./api/users/user.router");
const bookingConfigRouter = require("./api/booking-config/booking-config.router");
const roomRouter = require("./api/rooms/rooms.router");
const bookingRouter = require("./api/bookings/bookings.router");
const resturantRouter = require("./api/resturants/resturant.router");

// Routes
app.use("/api/admin", adminRouter);
app.use("/api/booking-config", bookingConfigRouter);
app.use("/api/users", userRouter);
app.use("/api/rooms", roomRouter);
app.use("/api/bookings", bookingRouter);
app.use("/api/resturant", resturantRouter);


app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


// Start the server
app.listen();